from tobrot.sample_config import Config
#Fill your all data, read readme for reference

class Config(Config):
	TG_BOT_TOKEN= "1268fill---your----data"
	APP_ID = 1373938
	API_HASH = "fill--your--data"
	OWNER_ID = "" #ID of bot owner
	AUTH_CHANNEL = [-10082786282972]
	DESTINATION_FOLDER = "HelloMan" #Name of your folder read readme
	RCLONE_CONFIG = """type = drive\nscope = drive\ntoken = {"access_token":"ya29.fill---your---data----7gGcxnYr71RBuoMVlzhAM_-fil your davxrOpIuvZ-S5lo4YzhYqP:"Bearer","refresh_token":"1//0gnh0j3fUzRITCgYIARAAGBASNwF-L9IrbbYT1QkJg6UCEo3AksHDp6DqUBrhcTBIwUWtlgmbnBQPZKvSAEOTl098VTt8zEojRnY","expiry":"2fill--your--data-07-13T10:4fillyourdata758376Z"}"""
	#fill taking reference of this config, dont remove """ from both side of the RCLONE_CONFIG variable 
